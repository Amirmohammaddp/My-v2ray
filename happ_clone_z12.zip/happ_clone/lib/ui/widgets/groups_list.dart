import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../models/connection_state.dart';
import '../../models/proxy_config.dart';
import '../../providers/providers.dart';
import '../screens/config_edit_screen.dart';
import 'anim.dart';
import 'config_tile.dart';
import 'group_tile.dart';

/// Selects [c] as active; reconnects if the VPN is currently on.
Future<void> selectConfig(WidgetRef ref, BuildContext context, ProxyConfig c) async {
  final wasOn = ref.read(xrayServiceProvider).status == VpnStatus.connected;
  ref.read(activeConfigIdProvider.notifier).set(c.id);
  if (!wasOn) return;
  try {
    final ctl = ref.read(connectionControllerProvider);
    await ctl.toggle(); // stop
    await ctl.toggle(); // start with the new config
  } catch (e) {
    if (context.mounted) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('$e')));
    }
  }
}

/// Config rows for one group (used inside the home card and in group tiles).
List<Widget> configTiles(WidgetRef ref, BuildContext context, List<ProxyConfig> list, String? activeId,
    {bool manage = true}) {
  if (list.isEmpty) {
    return [
      Padding(
        padding: const EdgeInsets.all(14),
        child: Text('No configs in this group', style: TextStyle(color: Theme.of(context).colorScheme.onSurfaceVariant)),
      ),
    ];
  }
  return [
    for (var i = 0; i < list.length; i++)
      FadeSlideIn(
        key: ValueKey(list[i].id),
        index: i,
        child: ConfigTile(
          config: list[i],
          selected: list[i].id == activeId,
          onTap: () => selectConfig(ref, context, list[i]),
          onEdit: manage
              ? () => Navigator.push(
                  context, MaterialPageRoute<void>(builder: (_) => ConfigEditScreen(initial: list[i])))
              : null,
          onDelete: manage ? () => ref.read(configsProvider.notifier).remove(list[i].id) : null,
        ),
      ),
  ];
}

/// Column of collapsible groups.
class GroupsList extends ConsumerStatefulWidget {
  final List<ConfigGroup> groups;
  const GroupsList({super.key, required this.groups});

  @override
  ConsumerState<GroupsList> createState() => _GroupsListState();
}

class _GroupsListState extends ConsumerState<GroupsList> {
  @override
  Widget build(BuildContext context) {
    final activeId = ref.watch(activeConfigProvider)?.id;
    final open = ref.watch(expandedGroupsProvider);
    return Column(
      children: [
        for (var i = 0; i < widget.groups.length; i++)
          FadeSlideIn(
            key: ValueKey(widget.groups[i].key),
            index: i,
            child: _tile(widget.groups[i], activeId, open),
          ),
      ],
    );
  }

  Widget _tile(ConfigGroup g, String? activeId, Set<String> open) {
    final n = g.configs.length;
    return GroupTile(
      title: g.name,
      subtitle: n == 1 ? '1 config' : '$n configs',
      expanded: open.contains(g.key),
      onToggle: () {
        final cur = ref.read(expandedGroupsProvider);
        ref.read(expandedGroupsProvider.notifier).state =
            cur.contains(g.key) ? ({...cur}..remove(g.key)) : {...cur, g.key};
      },
      trailing: g.sub == null
          ? null
          : PopupMenuButton<int>(
              icon: const Icon(Icons.more_vert_rounded, size: 20),
              onSelected: (v) async {
                final messenger = ScaffoldMessenger.of(context);
                if (v == 0) {
                  try {
                    final c = await ref.read(subscriptionsProvider.notifier).refreshOne(g.sub!.id);
                    messenger.showSnackBar(SnackBar(content: Text('Updated: $c configs')));
                  } catch (e) {
                    messenger.showSnackBar(SnackBar(content: Text('$e')));
                  }
                } else {
                  await ref.read(subscriptionsProvider.notifier).remove(g.sub!.id);
                }
              },
              itemBuilder: (_) => const [
                PopupMenuItem(value: 0, child: Text('Update')),
                PopupMenuItem(value: 1, child: Text('Delete group')),
              ],
            ),
      children: configTiles(ref, context, g.configs, activeId),
    );
  }
}
