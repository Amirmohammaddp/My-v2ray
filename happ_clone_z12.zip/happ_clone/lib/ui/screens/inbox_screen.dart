import 'package:flutter/material.dart';

import '../../services/notice_service.dart';
import '../theme.dart';
import '../widgets/anim.dart';

class InboxScreen extends StatefulWidget {
  const InboxScreen({super.key});
  @override
  State<InboxScreen> createState() => _InboxScreenState();
}

class _InboxScreenState extends State<InboxScreen> {
  List<Notice>? _items;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final l = await NoticeService.inbox();
    if (mounted) setState(() => _items = l);
  }

  Future<void> _refresh() async {
    await NoticeService.check(notify: false);
    await _load();
  }

  String _when(DateTime t) {
    String two(int v) => v.toString().padLeft(2, '0');
    return '${t.year}-${two(t.month)}-${two(t.day)}  ${two(t.hour)}:${two(t.minute)}';
  }

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    final items = _items;
    return Scaffold(
      appBar: AppBar(title: const Text('Inbox')),
      body: items == null
          ? const Center(child: CircularProgressIndicator())
          : RefreshIndicator(
              onRefresh: _refresh,
              child: items.isEmpty
                  ? ListView(children: [
                      const SizedBox(height: 140),
                      Icon(Icons.notifications_none_rounded, size: 52, color: AppTheme.iconOf(cs)),
                      const SizedBox(height: 12),
                      const Center(
                          child: Text('No announcements yet', style: TextStyle(fontSize: 17, fontWeight: FontWeight.w700))),
                      const SizedBox(height: 4),
                      Center(child: Text('Pull down to check', style: TextStyle(color: cs.onSurfaceVariant))),
                    ])
                  : ListView.builder(
                      padding: const EdgeInsets.fromLTRB(16, 8, 16, 30),
                      itemCount: items.length,
                      itemBuilder: (_, i) {
                        final n = items[i];
                        return FadeSlideIn(
                          index: i,
                          child: Container(
                            margin: const EdgeInsets.only(bottom: 10),
                            child: Material(
                              color: cs.surfaceContainerHigh,
                              borderRadius: BorderRadius.circular(20),
                              clipBehavior: Clip.antiAlias,
                              child: InkWell(
                                onTap: n.link.isEmpty ? null : () => NoticeService.openLink(n.link),
                                child: Padding(
                                  padding: const EdgeInsets.all(14),
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Row(children: [
                                        Icon(Icons.campaign_rounded, color: AppTheme.iconOf(cs), size: 20),
                                        const SizedBox(width: 8),
                                        Expanded(
                                          child: Text(n.title,
                                              style: TextStyle(
                                                  fontWeight: FontWeight.w800, fontSize: 15, color: cs.primary)),
                                        ),
                                      ]),
                                      if (n.body.isNotEmpty) ...[
                                        const SizedBox(height: 6),
                                        Text(n.body),
                                      ],
                                      const SizedBox(height: 8),
                                      Row(children: [
                                        Text(_when(n.time), style: TextStyle(fontSize: 11.5, color: cs.onSurfaceVariant)),
                                        const Spacer(),
                                        if (n.link.isNotEmpty)
                                          Icon(Icons.open_in_new_rounded, size: 16, color: cs.onSurfaceVariant),
                                      ]),
                                    ],
                                  ),
                                ),
                              ),
                            ),
                          ),
                        );
                      },
                    ),
            ),
    );
  }
}
