import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import 'l10n/strings.dart';
import 'models/app_settings.dart';
import 'services/notice_service.dart';
import 'providers/providers.dart';
import 'ui/add_actions.dart';
import 'ui/screens/configs_screen.dart';
import 'ui/screens/home_screen.dart';
import 'ui/screens/logs_screen.dart';
import 'ui/screens/settings_screen.dart';
import 'ui/theme.dart';
import 'ui/widgets/add_dock.dart';
import 'ui/widgets/nav_bar.dart';

class HappApp extends ConsumerWidget {
  const HappApp({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final theme = ref.watch(settingsProvider.select((s) => s.theme));
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Irisv2ray',
      theme: AppTheme.light(),
      darkTheme: AppTheme.dark(),
      themeMode: theme == AppThemeMode.dark ? ThemeMode.dark : ThemeMode.light,
      themeAnimationDuration: const Duration(milliseconds: 500),
      themeAnimationCurve: Curves.easeInOut,
      locale: const Locale('en'),
      supportedLocales: const [Locale('en'), Locale('fa')],
      localizationsDelegates: const [
        GlobalMaterialLocalizations.delegate,
        GlobalWidgetsLocalizations.delegate,
        GlobalCupertinoLocalizations.delegate,
      ],
      home: const RootShell(),
    );
  }
}

class RootShell extends ConsumerStatefulWidget {
  const RootShell({super.key});
  @override
  ConsumerState<RootShell> createState() => _RootShellState();
}

class _RootShellState extends ConsumerState<RootShell> {
  int _index = 0;
  bool _addOpen = false;
  static const _pages = <Widget>[HomeScreen(), ConfigsScreen(), LogsScreen(), SettingsScreen()];
  Timer? _auto;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) => _startup());
    _auto = Timer.periodic(const Duration(minutes: 5), (_) {
      _updateSubs(startup: false);
      _checkNews();
    });
  }

  @override
  void dispose() {
    _auto?.cancel();
    super.dispose();
  }

  Future<void> _checkNews() async {
    try {
      final n = await NoticeService.check(notify: true);
      if (n > 0) ref.read(logsProvider.notifier).add('Info', '$n new announcement(s)');
    } catch (_) {}
  }

  Future<void> _startup() async {
    NoticeService.setEnabled(ref.read(settingsProvider).notifications);
    _checkNews();
    await _updateSubs(startup: true);
    if (!mounted) return;
    if (ref.read(settingsProvider).pingOnStart && ref.read(configsProvider).isNotEmpty) {
      ref.read(logsProvider.notifier).add('Info', 'ping on start');
      await ref.read(configsProvider.notifier).pingAll();
    }
  }

  Future<void> _updateSubs({required bool startup}) async {
    final mode = ref.read(settingsProvider).autoUpdate;
    final interval = mode.interval;
    if (interval == null) return;
    if (!startup && interval == Duration.zero) return;
    final now = DateTime.now();
    for (final s in [...ref.read(subscriptionsProvider)]) {
      final last = s.lastUpdated;
      final stale = last == null || now.difference(last) >= interval;
      if (!stale) continue;
      try {
        await ref.read(subscriptionsProvider.notifier).refreshOne(s.id);
      } catch (e) {
        ref.read(logsProvider.notifier).add('Warn', 'auto-update ${s.name} failed: $e');
      }
    }
  }

  Future<void> _pick(AddKind k) async {
    setState(() => _addOpen = false);
    await Future<void>.delayed(const Duration(milliseconds: 250));
    if (!mounted) return;
    switch (k) {
      case AddKind.qr:
        await AddActions.qr(context, ref);
        break;
      case AddKind.clipboard:
        await AddActions.clipboard(context, ref);
        break;
      case AddKind.subscription:
        await AddActions.subscription(context, ref);
        break;
      case AddKind.manual:
        AddActions.manual(context);
        break;
    }
  }

  @override
  Widget build(BuildContext context) {
    ref.listen(logsProvider, (_, __) {}); // keep the log collector alive from app start
    final zen = ref.watch(settingsProvider.select((s) => s.zenMode));
    final showAdd = (_index == 0 && !zen) || _index == 1;
    final open = _addOpen && showAdd;

    return PopScope(
      canPop: !open && _index == 0,
      onPopInvokedWithResult: (didPop, _) {
        if (didPop) return;
        setState(() {
          if (_addOpen) {
            _addOpen = false;
          } else {
            _index = 0;
          }
        });
      },
      child: Scaffold(
        body: Stack(
          children: [
            Positioned.fill(
              child: AnimatedSwitcher(
                duration: const Duration(milliseconds: 320),
                transitionBuilder: (child, anim) => FadeTransition(
                  opacity: anim,
                  child: SlideTransition(
                    position: Tween<Offset>(begin: const Offset(0, 0.03), end: Offset.zero).animate(anim),
                    child: child,
                  ),
                ),
                child: KeyedSubtree(key: ValueKey(_index), child: _pages[_index]),
              ),
            ),
            Positioned.fill(
              child: IgnorePointer(
                ignoring: !open,
                child: GestureDetector(
                  onTap: () => setState(() => _addOpen = false),
                  child: AnimatedOpacity(
                    opacity: open ? 1 : 0,
                    duration: const Duration(milliseconds: 300),
                    child: const ColoredBox(color: Color(0x99000000)),
                  ),
                ),
              ),
            ),
            Positioned(
              left: 20,
              right: 20,
              bottom: 16,
              child: IgnorePointer(
                ignoring: !showAdd,
                child: AnimatedSlide(
                  offset: showAdd ? Offset.zero : const Offset(0, 1.8),
                  duration: const Duration(milliseconds: 450),
                  curve: Curves.easeOutCubic,
                  child: AnimatedOpacity(
                    opacity: showAdd ? 1 : 0,
                    duration: const Duration(milliseconds: 300),
                    child: AddDock(
                      open: open,
                      onToggle: () => setState(() => _addOpen = !_addOpen),
                      onPick: _pick,
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
        bottomNavigationBar: AppNavBar(
          index: _index,
          onChanged: (i) => setState(() {
            _index = i;
            _addOpen = false;
          }),
        ),
      ),
    );
  }
}

/// UI is English-only.
final stringsProvider = Provider<AppStrings>((ref) => AppStrings.of(AppLanguage.en));
