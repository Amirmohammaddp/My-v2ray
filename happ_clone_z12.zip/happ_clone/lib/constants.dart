const kTelegramId = 'Mramirmohammadp';
const kTelegramUrl = 'https://t.me/$kTelegramId';

/// Announcements feed (a small JSON file you edit to push notifications).
const kNewsUrl = 'https://raw.githubusercontent.com/Amirmohammaddp/Iris-vpn/main/news.json';
