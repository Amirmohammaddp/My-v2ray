import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:url_launcher/url_launcher.dart';

import '../constants.dart';

/// Opens the developer's Telegram chat; falls back to copying the ID.
Future<void> openTelegram(BuildContext context) async {
  var ok = false;
  try {
    ok = await launchUrl(Uri.parse(kTelegramUrl), mode: LaunchMode.externalApplication);
  } catch (_) {
    ok = false;
  }
  if (!ok) {
    await Clipboard.setData(const ClipboardData(text: '@$kTelegramId'));
    if (context.mounted) {
      ScaffoldMessenger.of(context)
          .showSnackBar(const SnackBar(content: Text('Could not open Telegram. ID copied: @$kTelegramId')));
    }
  }
}
