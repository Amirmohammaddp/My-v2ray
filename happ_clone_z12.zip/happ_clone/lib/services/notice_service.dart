import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:ui' show DartPluginRegistrant;

import 'package:flutter/widgets.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:path_provider/path_provider.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:workmanager/workmanager.dart';

import '../constants.dart';

class Notice {
  final int id;
  final String title;
  final String body;
  final String link;
  final DateTime time;
  const Notice({required this.id, required this.title, required this.body, required this.link, required this.time});

  Map<String, dynamic> toJson() =>
      {'id': id, 'title': title, 'body': body, 'link': link, 'time': time.toIso8601String()};

  factory Notice.fromJson(Map<String, dynamic> j) => Notice(
        id: (j['id'] as num).toInt(),
        title: '${j['title'] ?? ''}',
        body: '${j['body'] ?? ''}',
        link: '${j['link'] ?? ''}',
        time: DateTime.tryParse('${j['time'] ?? ''}') ?? DateTime.now(),
      );
}

const _task = 'iris-news';

/// Background entry point (runs in its own isolate via WorkManager).
@pragma('vm:entry-point')
void noticeCallbackDispatcher() {
  Workmanager().executeTask((task, input) async {
    WidgetsFlutterBinding.ensureInitialized();
    DartPluginRegistrant.ensureInitialized();
    try {
      await NoticeService.check(notify: true);
    } catch (_) {}
    return true;
  });
}

/// Announcements: polls [kNewsUrl], shows notifications, keeps an inbox.
/// State is a small JSON file so the background isolate and the UI share it.
class NoticeService {
  static final _plugin = FlutterLocalNotificationsPlugin();
  static bool _inited = false;

  static Future<File> _file() async {
    final d = await getApplicationSupportDirectory();
    return File('${d.path}/inbox.json');
  }

  static Future<Map<String, dynamic>> _read() async {
    try {
      final f = await _file();
      if (!await f.exists()) return {};
      return jsonDecode(await f.readAsString()) as Map<String, dynamic>;
    } catch (_) {
      return {};
    }
  }

  static Future<void> _write(Map<String, dynamic> m) async {
    final f = await _file();
    await f.writeAsString(jsonEncode(m));
  }

  static Future<void> _initPlugin({DidReceiveNotificationResponseCallback? onTap}) async {
    await _plugin.initialize(
      const InitializationSettings(android: AndroidInitializationSettings('@mipmap/ic_launcher')),
      onDidReceiveNotificationResponse: onTap,
    );
    _inited = true;
  }

  static Future<void> _open(String? link) async {
    if (link == null || link.isEmpty) return;
    try {
      await launchUrl(Uri.parse(link), mode: LaunchMode.externalApplication);
    } catch (_) {}
  }

  /// Call once from main().
  static Future<void> initMain() async {
    await _initPlugin(onTap: (r) => _open(r.payload));
    final d = await _plugin.getNotificationAppLaunchDetails();
    if (d?.didNotificationLaunchApp ?? false) {
      await _open(d!.notificationResponse?.payload);
    }
  }

  static Future<bool> requestPermission() async {
    final impl = _plugin.resolvePlatformSpecificImplementation<AndroidFlutterLocalNotificationsPlugin>();
    return (await impl?.requestNotificationsPermission()) ?? false;
  }

  static Future<void> openLink(String link) => _open(link);

  static Future<List<Notice>> inbox() async {
    final m = await _read();
    final items = (m['items'] as List?) ?? const [];
    return [
      for (final e in items)
        if (e is Map<String, dynamic>) Notice.fromJson(e),
    ];
  }

  /// Turns background checking on/off.
  static Future<void> setEnabled(bool on) async {
    final m = await _read();
    m['enabled'] = on;
    await _write(m);
    try {
      if (on) {
        await Workmanager().initialize(noticeCallbackDispatcher);
        await Workmanager().registerPeriodicTask(
          _task,
          _task,
          frequency: const Duration(minutes: 15),
          constraints: Constraints(networkType: NetworkType.connected),
          existingWorkPolicy: ExistingPeriodicWorkPolicy.update,
        );
        await requestPermission();
      } else {
        await Workmanager().cancelByUniqueName(_task);
      }
    } catch (_) {}
  }

  /// Fetches the feed; returns how many new items were found.
  static Future<int> check({bool notify = true}) async {
    final m = await _read();
    if (m['enabled'] == false) return 0;

    final client = HttpClient()..connectionTimeout = const Duration(seconds: 10);
    String text;
    try {
      final uri = Uri.parse('$kNewsUrl?t=${DateTime.now().millisecondsSinceEpoch}');
      final req = await client.getUrl(uri).timeout(const Duration(seconds: 12));
      final res = await req.close().timeout(const Duration(seconds: 12));
      if (res.statusCode != 200) return 0;
      text = await res.transform(utf8.decoder).join().timeout(const Duration(seconds: 12));
    } catch (_) {
      return 0;
    } finally {
      client.close(force: true);
    }

    final dynamic data;
    try {
      data = jsonDecode(text);
    } catch (_) {
      return 0;
    }
    final raw = data is List ? data : [data];
    final lastId = (m['lastId'] as num?)?.toInt() ?? 0;
    final fresh = <Notice>[];
    for (final e in raw) {
      if (e is! Map) continue;
      final id = (e['id'] as num?)?.toInt();
      if (id == null || id <= lastId) continue;
      fresh.add(Notice(
        id: id,
        title: '${e['title'] ?? 'Irisv2ray'}',
        body: '${e['body'] ?? ''}',
        link: '${e['link'] ?? ''}',
        time: DateTime.now(),
      ));
    }
    if (fresh.isEmpty) return 0;
    fresh.sort((a, b) => a.id.compareTo(b.id));

    final items = [for (final n in fresh.reversed) n.toJson(), ...((m['items'] as List?) ?? const [])];
    m['items'] = items.take(50).toList();
    m['lastId'] = fresh.last.id;
    await _write(m);

    if (notify) {
      for (final n in fresh) {
        await _show(n);
      }
    }
    return fresh.length;
  }

  static Future<void> _show(Notice n) async {
    if (!_inited) await _initPlugin();
    await _plugin.show(
      n.id,
      n.title,
      n.body,
      NotificationDetails(
        android: AndroidNotificationDetails(
          'news',
          'Announcements',
          channelDescription: 'Offers and news from Irisv2ray',
          importance: Importance.high,
          priority: Priority.high,
          styleInformation: BigTextStyleInformation(n.body),
        ),
      ),
      payload: n.link,
    );
  }
}
